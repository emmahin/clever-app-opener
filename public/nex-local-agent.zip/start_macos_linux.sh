#!/usr/bin/env bash
set -e
if [ -z "$NEX_AGENT_TOKEN" ]; then
  echo "ERREUR : exporte d'abord NEX_AGENT_TOKEN"
  echo "  python3 -c 'import secrets; print(secrets.token_urlsafe(32))'"
  echo "  export NEX_AGENT_TOKEN=ton_token"
  exit 1
fi
python3 -m pip install --quiet -r requirements.txt
python3 agent.py
