@echo off
REM ─── Nex Local Agent — démarrage Windows ───
REM 1) Installe les dépendances (première fois uniquement)
REM 2) Lance l'agent avec ton token

if "%NEX_AGENT_TOKEN%"=="" (
  echo.
  echo  ERREUR : la variable NEX_AGENT_TOKEN n'est pas definie.
  echo.
  echo  Genere un token avec :
  echo    python -c "import secrets; print(secrets.token_urlsafe(32))"
  echo.
  echo  Puis relance ce script comme ceci :
  echo    set NEX_AGENT_TOKEN=colle_ton_token_ici
  echo    START_WINDOWS.bat
  echo.
  pause
  exit /b 1
)

python -m pip install --quiet -r requirements.txt
python agent.py
pause
